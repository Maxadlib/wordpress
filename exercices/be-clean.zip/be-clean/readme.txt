/**
 * @package 	WordPress
 * @subpackage 	Be Clean
 * @version 	1.0.5
 * 
 * Theme Information
 * Created by CMSMasters
 * 
 */

To update your theme please use the files list from the FILE LOGS below and substitute/add the listed files on your server with the same files in the Updates folder.

Important: after you have updated the theme, in your admin panel please proceed to
Theme Settings - Fonts and click "Save" in any tab,
then proceed to 
Theme Settings - Colors and click "Save" in any tab here.


-----------------------------------------------------------------------
				FILE LOGS
-----------------------------------------------------------------------


Version 1.0.5: files operations:

	Theme Files edited:
		be-clean/archive.php
		be-clean/author.php
		be-clean/css/adaptive.css
		be-clean/css/less/adaptive.less
		be-clean/css/less/style.less
		be-clean/framework/admin/inc/plugin-activator.php
		be-clean/framework/admin/inc/plugins/cmsmasters-contact-form-builder.zip
		be-clean/framework/admin/inc/plugins/cmsmasters-content-composer.zip
		be-clean/framework/admin/inc/plugins/cmsmasters-mega-menu.zip
		be-clean/framework/admin/inc/plugins/LayerSlider.zip
		be-clean/framework/admin/inc/plugins/revslider.zip
		be-clean/framework/admin/options/js/cmsmasters-theme-options.js
		be-clean/framework/admin/settings/js/cmsmasters-theme-settings.js
		be-clean/framework/function/likes.php
		be-clean/framework/function/pagination.php
		be-clean/framework/function/template-functions.php
		be-clean/framework/function/theme-fonts.php
		be-clean/framework/function/theme-functions.php
		be-clean/framework/languages/be-clean.pot
		be-clean/functions.php
		be-clean/index.php
		be-clean/js/jquery.script.js
		be-clean/readme.txt
		be-clean/search.php
		be-clean/style.css
		
	Theme Files added:
		be-clean/framework/class/likes-posttype.php
		
	Theme Files deleted:
		be-clean/css/styles/be-clean.css
		be-clean/css/styles/be-clean_colors_primary.css
		be-clean/css/styles/be-clean_colors_secondary.css
		be-clean/css/styles/be-clean_fonts.css



--------------------------------------


Version 1.0.4: files operations:

	Theme Files edited:
		be-clean\framework\admin\inc\plugin-activator.php
		be-clean\framework\admin\inc\plugins\cmsmasters-content-composer.zip
		be-clean\framework\admin\inc\plugins\LayerSlider.zip
		be-clean\readme.txt
		be-clean\css\less\style.less
		be-clean\framework\function\template-functions-post.php
		be-clean\style.css

	
	Proceed to wp-content\plugins\LayerSlider 
	and update all files in this folder to version 5.6.9



--------------------------------------


Version 1.0.3: files operations:

	Theme Files added:
		be-clean\framework\class\Browser.php
	
	Theme Files edited:	
		be-clean\style.css
		be-clean\js\jquery.cmsmasters-woo-script.js
		be-clean\js\jquery.script.js
		be-clean\404.php
		be-clean\footer.php
		be-clean\framework\admin\inc\plugin-activator.php
		be-clean\framework\admin\options\cmsmasters-theme-options-general.php
		be-clean\framework\admin\options\cmsmasters-theme-options-other.php
		be-clean\framework\admin\options\cmsmasters-theme-options-page.php
		be-clean\framework\admin\options\cmsmasters-theme-options-post.php
		be-clean\framework\admin\options\cmsmasters-theme-options-product.php
		be-clean\framework\admin\options\cmsmasters-theme-options-profile.php
		be-clean\framework\admin\options\cmsmasters-theme-options-project.php
		be-clean\framework\admin\settings\cmsmasters-theme-settings.php
		be-clean\framework\admin\settings\cmsmasters-theme-settings-color.php
		be-clean\framework\admin\settings\cmsmasters-theme-settings-demo.php
		be-clean\framework\admin\settings\cmsmasters-theme-settings-element.php
		be-clean\framework\admin\settings\cmsmasters-theme-settings-font.php
		be-clean\framework\admin\settings\cmsmasters-theme-settings-general.php
		be-clean\framework\admin\settings\cmsmasters-theme-settings-single.php
		be-clean\framework\class\class-tgm-plugin-activation.php
		be-clean\framework\function\template-functions.php
		be-clean\framework\function\template-functions-post.php
		be-clean\framework\function\template-functions-profile.php
		be-clean\framework\function\template-functions-project.php
		be-clean\framework\function\theme-colored-categories.php
		be-clean\framework\function\theme-colors-primary.php
		be-clean\framework\function\theme-colors-secondary.php
		be-clean\framework\function\theme-fonts.php
		be-clean\framework\function\theme-functions.php
		be-clean\framework\postType\blog\post\audio.php
		be-clean\framework\postType\blog\post\gallery.php
		be-clean\framework\postType\blog\post\image.php
		be-clean\framework\postType\blog\post\standard.php
		be-clean\framework\postType\blog\post\video.php
		be-clean\framework\postType\portfolio\post\gallery.php
		be-clean\framework\postType\portfolio\post\standard.php
		be-clean\framework\postType\portfolio\post\video.php
		be-clean\framework\postType\profile\post\standard.php
		be-clean\functions.php
		be-clean\sidebar-bottom.php
		be-clean\archive.php
		be-clean\author.php
		be-clean\search.php
		be-clean\single.php
		be-clean\single-profile.php
		be-clean\single-project.php
		be-clean\sitemap.php
		be-clean\woocommerce\cmsmasters-woo-functions.php
		be-clean\woocommerce\single-product\product-image.php
		be-clean\woocommerce\single-product\product-thumbnails.php
		be-clean\framework\languages\be-clean.pot
		be-clean\readme.txt




	Proceed to wp-content\plugins\cmsmasters-content-composer 
	and update all files in this folder to version 1.5.5	
		
	Proceed to wp-content\plugins\cmsmasters-contact-form-builder 
	and update all files in this folder to version 1.3.7
	
	Proceed to wp-content\plugins\revslider 
	and update all files in this folder to version 5.2.6



--------------------------------------


Version 1.0.2: files operations:

	Theme Files edited:
		be-clean\css\less\style.less
		be-clean\css\retina.css
		be-clean\framework\admin\settings\cmsmasters-theme-settings-element.php
		be-clean\framework\function\theme-functions.php
		be-clean\functions.php
		be-clean\readme.txt
		be-clean\style.css

	
	Proceed to wp-content\plugins\cmsmasters-content-composer 
	and update all files in this folder to version 1.5.5	



--------------------------------------


Version 1.0.1: files operations:

	Theme Files deleted:
		be-clean\css\rtl.css
		be-clean\framework\admin\settings\inc\settings-export.php
		be-clean\framework\admin\settings\inc\settings-import.php
		be-clean\framework\function\like.php
	
	
	Theme Files edited:
		be-clean\archive.php
		be-clean\author.php
		be-clean\css\adaptive.css
		be-clean\css\less\adaptive.less
		be-clean\css\less\style.less
		be-clean\footer.php
		be-clean\framework\admin\inc\admin-scripts.php
		be-clean\framework\admin\inc\css\jquery.cmsmastersLightbox.css
		be-clean\framework\admin\inc\css\jquery.cmsmastersLightbox-rtl.css
		be-clean\framework\admin\inc\js\jquery.cmsmastersLightbox.js
		be-clean\framework\admin\inc\plugin-activator.php
		be-clean\framework\admin\options\cmsmasters-theme-options.php
		be-clean\framework\admin\settings\cmsmasters-theme-settings.php
		be-clean\framework\admin\settings\cmsmasters-theme-settings-general.php
		be-clean\framework\admin\settings\cmsmasters-theme-settings-single.php
		be-clean\framework\admin\settings\js\cmsmasters-theme-settings.js
		be-clean\framework\class\class-tgm-plugin-activation.php
		be-clean\framework\class\twitteroauth.php
		be-clean\framework\class\likes-posttype.php
		be-clean\framework\function\template-functions.php
		be-clean\framework\function\template-functions-shortcodes.php
		be-clean\framework\function\theme-colors-primary.php
		be-clean\framework\function\theme-colors-secondary.php
		be-clean\framework\function\theme-fonts.php
		be-clean\framework\function\theme-functions.php
		be-clean\framework\languages\be-clean.pot
		be-clean\framework\postType\posts-slider\blog\audio.php
		be-clean\framework\postType\posts-slider\blog\gallery.php
		be-clean\framework\postType\posts-slider\blog\image.php
		be-clean\framework\postType\posts-slider\blog\standard.php
		be-clean\framework\postType\posts-slider\blog\video.php
		be-clean\functions.php
		be-clean\header.php
		be-clean\js\jquery.isotope.mode.js
		be-clean\js\jquery.script.js
		be-clean\js\jsLibraries.min.js
		be-clean\readme.txt
		be-clean\rtl.css
		be-clean\search.php
		be-clean\style.css
		be-clean\woocommerce\archive-product.php
		be-clean\woocommerce\content-product.php
		be-clean\woocommerce\content-single-product.php
		be-clean\woocommerce\global\sidebar.php
		be-clean\woocommerce\global\wrapper-end.php
		be-clean\woocommerce\global\wrapper-start.php
		be-clean\woocommerce\loop\loop-start.php
		be-clean\woocommerce\loop\pagination.php
		be-clean\woocommerce\single-product.php
		be-clean\woocommerce\single-product-reviews.php
		be-clean\woocommerce\single-product\meta.php
		be-clean\woocommerce\single-product\product-image.php
		be-clean\woocommerce\single-product\product-thumbnails.php
		be-clean\woocommerce\single-product\review.php
		be-clean\woocommerce\single-product\tabs\tabs.php

		
		
	Proceed to wp-content\plugins\cmsmasters-content-composer 
	and update all files in this folder to version 1.5.5
	
	Proceed to wp-content\plugins\cmsmasters-contact-form-builder
	and update all files in this folder to version 1.3.6
	
	Proceed to wp-content\plugins\LayerSlider 
	and update all files in this folder to version 5.6.8
	
	Proceed to wp-content\plugins\revslider 
	and update all files in this folder to version 5.2.5.4



--------------------------------------
Version 1.0: Release!

