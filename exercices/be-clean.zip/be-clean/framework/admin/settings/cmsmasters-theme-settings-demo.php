<?php 
/**
 * @package 	WordPress
 * @subpackage 	Be Clean
 * @version		1.0.3
 * 
 * Admin Panel Theme Settings Import/Export
 * Created by CMSMasters
 * 
 */


function be_clean_options_demo_tabs() {
	$tabs = array();
	
	
	$tabs['import'] = esc_attr__('Import', 'be-clean');
	$tabs['export'] = esc_attr__('Export', 'be-clean');
	
	
	return $tabs;
}


function be_clean_options_demo_sections() {
	$tab = be_clean_get_the_tab();
	
	
	switch ($tab) {
	case 'import':
		$sections = array();
		
		$sections['import_section'] = esc_html__('Theme Settings Import', 'be-clean');
		
		
		break;
	case 'export':
		$sections = array();
		
		$sections['export_section'] = esc_html__('Theme Settings Export', 'be-clean');
		
		
		break;
	default:
		$sections = array();
		
		
		break;
	}
	
	
	return $sections;
} 


function be_clean_options_demo_fields($set_tab = false) {
	if ($set_tab) {
		$tab = $set_tab;
	} else {
		$tab = be_clean_get_the_tab();
	}
	
	
	$options = array();
	
	
	switch ($tab) {
	case 'import':
		$options[] = array( 
			'section' => 'import_section', 
			'id' => 'be-clean' . '_demo_import', 
			'title' => esc_html__('Theme Settings', 'be-clean'), 
			'desc' => esc_html__("Enter your theme settings data here and click 'Import' button", 'be-clean'), 
			'type' => 'textarea', 
			'std' => '', 
			'class' => '' 
		);
		
		
		break;
	case 'export':
		$options[] = array( 
			'section' => 'export_section', 
			'id' => 'be-clean' . '_demo_export', 
			'title' => esc_html__('Theme Settings', 'be-clean'), 
			'desc' => esc_html__("Click here to export your theme settings data to the file", 'be-clean'), 
			'type' => 'button', 
			'std' => esc_html__('Export Theme Settings', 'be-clean'), 
			'class' => 'cmsmasters-demo-export' 
		);
		
		
		break;
	}
	
	
	return $options;	
}

