<?php 
/**
 * @package 	WordPress
 * @subpackage 	Be Clean
 * @version 	1.0.3
 * 
 * Admin Panel Element Options
 * Created by CMSMasters
 * 
 */


function be_clean_options_element_tabs() {
	$tabs = array();
	
	$tabs['sidebar'] = esc_attr__('Sidebars', 'be-clean');
	$tabs['icon'] = esc_attr__('Social Icons', 'be-clean');
	$tabs['lightbox'] = esc_attr__('Lightbox', 'be-clean');
	$tabs['sitemap'] = esc_attr__('Sitemap', 'be-clean');
	$tabs['error'] = esc_attr__('404', 'be-clean');
	$tabs['code'] = esc_attr__('Custom Codes', 'be-clean');
	
	if (class_exists('Cmsmasters_Form_Builder')) {
		$tabs['recaptcha'] = esc_attr__('reCAPTCHA', 'be-clean');
	}
	
	return $tabs;
}


function be_clean_options_element_sections() {
	$tab = be_clean_get_the_tab();
	
	switch ($tab) {
	case 'sidebar':
		$sections = array();
		
		$sections['sidebar_section'] = esc_attr__('Custom Sidebars', 'be-clean');
		
		break;
	case 'icon':
		$sections = array();
		
		$sections['icon_section'] = esc_attr__('Social Icons', 'be-clean');
		
		break;
	case 'lightbox':
		$sections = array();
		
		$sections['lightbox_section'] = esc_attr__('Theme Lightbox Options', 'be-clean');
		
		break;
	case 'sitemap':
		$sections = array();
		
		$sections['sitemap_section'] = esc_attr__('Sitemap Page Options', 'be-clean');
		
		break;
	case 'error':
		$sections = array();
		
		$sections['error_section'] = esc_attr__('404 Error Page Options', 'be-clean');
		
		break;
	case 'code':
		$sections = array();
		
		$sections['code_section'] = esc_attr__('Custom Codes', 'be-clean');
		
		break;
	case 'recaptcha':
		$sections = array();
		
		$sections['recaptcha_section'] = esc_attr__('Form Builder Plugin reCAPTCHA Keys', 'be-clean');
		
		break;
	default:
		$sections = array();
		
		
		break;
	}
	
	return $sections;	
} 


function be_clean_options_element_fields($set_tab = false) {
	if ($set_tab) {
		$tab = $set_tab;
	} else {
		$tab = be_clean_get_the_tab();
	}
	
	$options = array();
	
	switch ($tab) {
	case 'sidebar':
		$options[] = array( 
			'section' => 'sidebar_section', 
			'id' => 'be-clean' . '_sidebar', 
			'title' => esc_html__('Custom Sidebars', 'be-clean'), 
			'desc' => '', 
			'type' => 'sidebar', 
			'std' => '' 
		);
		
		break;
	case 'icon':
		$options[] = array( 
			'section' => 'icon_section', 
			'id' => 'be-clean' . '_social_icons', 
			'title' => esc_html__('Social Icons', 'be-clean'), 
			'desc' => '', 
			'type' => 'social', 
			'std' => array( 
				'cmsmasters-icon-facebook-1|#|' . esc_html__('Facebook', 'be-clean') . '|true|#4d67a3|#5b7dc1', 
				'cmsmasters-icon-gplus-1|#|' . esc_html__('Google+', 'be-clean') . '|true|#d74936|#f4403d', 
				'cmsmasters-icon-instagram|#|' . esc_html__('Instagram', 'be-clean') . '|true|#40719a|#569ace', 
				'cmsmasters-icon-twitter|#|' . esc_html__('Twitter', 'be-clean') . '|true|#25a7df|#28bfed', 
				'cmsmasters-icon-youtube-play|#|' . esc_html__('YouTube', 'be-clean') . '|true|#cc171e|#e2184e' 
			) 
		);
		
		break;
	case 'lightbox':
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_skin', 
			'title' => esc_html__('Skin', 'be-clean'), 
			'desc' => '', 
			'type' => 'select', 
			'std' => 'dark', 
			'choices' => array( 
				esc_html__('Dark', 'be-clean') . '|dark', 
				esc_html__('Light', 'be-clean') . '|light', 
				esc_html__('Mac', 'be-clean') . '|mac', 
				esc_html__('Metro Black', 'be-clean') . '|metro-black', 
				esc_html__('Metro White', 'be-clean') . '|metro-white', 
				esc_html__('Parade', 'be-clean') . '|parade', 
				esc_html__('Smooth', 'be-clean') . '|smooth' 
			) 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_path', 
			'title' => esc_html__('Path', 'be-clean'), 
			'desc' => esc_html__('Sets path for switching windows', 'be-clean'), 
			'type' => 'radio', 
			'std' => 'vertical', 
			'choices' => array( 
				esc_html__('Vertical', 'be-clean') . '|vertical', 
				esc_html__('Horizontal', 'be-clean') . '|horizontal' 
			) 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_infinite', 
			'title' => esc_html__('Infinite', 'be-clean'), 
			'desc' => esc_html__('Sets the ability to infinite the group', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 0 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_aspect_ratio', 
			'title' => esc_html__('Keep Aspect Ratio', 'be-clean'), 
			'desc' => esc_html__('Sets the resizing method used to keep aspect ratio within the viewport', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_mobile_optimizer', 
			'title' => esc_html__('Mobile Optimizer', 'be-clean'), 
			'desc' => esc_html__('Make lightboxes optimized for giving better experience with mobile devices', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_max_scale', 
			'title' => esc_html__('Max Scale', 'be-clean'), 
			'desc' => esc_html__('Sets the maximum viewport scale of the content', 'be-clean'), 
			'type' => 'number', 
			'std' => 1, 
			'min' => 0.1, 
			'max' => 2, 
			'step' => 0.05 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_min_scale', 
			'title' => esc_html__('Min Scale', 'be-clean'), 
			'desc' => esc_html__('Sets the minimum viewport scale of the content', 'be-clean'), 
			'type' => 'number', 
			'std' => 0.2, 
			'min' => 0.1, 
			'max' => 2, 
			'step' => 0.05 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_inner_toolbar', 
			'title' => esc_html__('Inner Toolbar', 'be-clean'), 
			'desc' => esc_html__('Bring buttons into windows, or let them be over the overlay', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 0 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_smart_recognition', 
			'title' => esc_html__('Smart Recognition', 'be-clean'), 
			'desc' => esc_html__('Sets content auto recognize from web pages', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 0 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_fullscreen_one_slide', 
			'title' => esc_html__('Fullscreen One Slide', 'be-clean'), 
			'desc' => esc_html__('Decide to fullscreen only one slide or hole gallery the fullscreen mode', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 0 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_fullscreen_viewport', 
			'title' => esc_html__('Fullscreen Viewport', 'be-clean'), 
			'desc' => esc_html__('Sets the resizing method used to fit content within the fullscreen mode', 'be-clean'), 
			'type' => 'select', 
			'std' => 'center', 
			'choices' => array( 
				esc_html__('Center', 'be-clean') . '|center', 
				esc_html__('Fit', 'be-clean') . '|fit', 
				esc_html__('Fill', 'be-clean') . '|fill', 
				esc_html__('Stretch', 'be-clean') . '|stretch' 
			) 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_controls_toolbar', 
			'title' => esc_html__('Toolbar Controls', 'be-clean'), 
			'desc' => esc_html__('Sets buttons be available or not', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_controls_arrows', 
			'title' => esc_html__('Arrow Controls', 'be-clean'), 
			'desc' => esc_html__('Enable the arrow buttons', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 0 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_controls_fullscreen', 
			'title' => esc_html__('Fullscreen Controls', 'be-clean'), 
			'desc' => esc_html__('Sets the fullscreen button', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_controls_thumbnail', 
			'title' => esc_html__('Thumbnails Controls', 'be-clean'), 
			'desc' => esc_html__('Sets the thumbnail navigation', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_controls_keyboard', 
			'title' => esc_html__('Keyboard Controls', 'be-clean'), 
			'desc' => esc_html__('Sets the keyboard navigation', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_controls_mousewheel', 
			'title' => esc_html__('Mouse Wheel Controls', 'be-clean'), 
			'desc' => esc_html__('Sets the mousewheel navigation', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_controls_swipe', 
			'title' => esc_html__('Swipe Controls', 'be-clean'), 
			'desc' => esc_html__('Sets the swipe navigation', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'be-clean' . '_ilightbox_controls_slideshow', 
			'title' => esc_html__('Slideshow Controls', 'be-clean'), 
			'desc' => esc_html__('Enable the slideshow feature and button', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 0 
		);
		
		break;
	case 'sitemap':
		$options[] = array( 
			'section' => 'sitemap_section', 
			'id' => 'be-clean' . '_sitemap_nav', 
			'title' => esc_html__('Website Pages', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'sitemap_section', 
			'id' => 'be-clean' . '_sitemap_categs', 
			'title' => esc_html__('Blog Archives by Categories', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'sitemap_section', 
			'id' => 'be-clean' . '_sitemap_tags', 
			'title' => esc_html__('Blog Archives by Tags', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'sitemap_section', 
			'id' => 'be-clean' . '_sitemap_month', 
			'title' => esc_html__('Blog Archives by Month', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'sitemap_section', 
			'id' => 'be-clean' . '_sitemap_pj_categs', 
			'title' => esc_html__('Portfolio Archives by Categories', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'sitemap_section', 
			'id' => 'be-clean' . '_sitemap_pj_tags', 
			'title' => esc_html__('Portfolio Archives by Tags', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		break;
	case 'error':
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'be-clean' . '_error_color', 
			'title' => esc_html__('Text Color', 'be-clean'), 
			'desc' => '', 
			'type' => 'rgba', 
			'std' => '#292929' 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'be-clean' . '_error_bg_color', 
			'title' => esc_html__('Background Color', 'be-clean'), 
			'desc' => '', 
			'type' => 'rgba', 
			'std' => '#fbfbfb' 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'be-clean' . '_error_bg_img_enable', 
			'title' => esc_html__('Background Image Visibility', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 0 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'be-clean' . '_error_bg_image', 
			'title' => esc_html__('Background Image', 'be-clean'), 
			'desc' => esc_html__('Choose your custom error page background image.', 'be-clean'), 
			'type' => 'upload', 
			'std' => '', 
			'frame' => 'select', 
			'multiple' => false 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'be-clean' . '_error_bg_rep', 
			'title' => esc_html__('Background Repeat', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'no-repeat', 
			'choices' => array( 
				esc_html__('No Repeat', 'be-clean') . '|no-repeat', 
				esc_html__('Repeat Horizontally', 'be-clean') . '|repeat-x', 
				esc_html__('Repeat Vertically', 'be-clean') . '|repeat-y', 
				esc_html__('Repeat', 'be-clean') . '|repeat' 
			) 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'be-clean' . '_error_bg_pos', 
			'title' => esc_html__('Background Position', 'be-clean'), 
			'desc' => '', 
			'type' => 'select', 
			'std' => 'top center', 
			'choices' => array( 
				esc_html__('Top Left', 'be-clean') . '|top left', 
				esc_html__('Top Center', 'be-clean') . '|top center', 
				esc_html__('Top Right', 'be-clean') . '|top right', 
				esc_html__('Center Left', 'be-clean') . '|center left', 
				esc_html__('Center Center', 'be-clean') . '|center center', 
				esc_html__('Center Right', 'be-clean') . '|center right', 
				esc_html__('Bottom Left', 'be-clean') . '|bottom left', 
				esc_html__('Bottom Center', 'be-clean') . '|bottom center', 
				esc_html__('Bottom Right', 'be-clean') . '|bottom right' 
			) 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'be-clean' . '_error_bg_att', 
			'title' => esc_html__('Background Attachment', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'scroll', 
			'choices' => array( 
				esc_html__('Scroll', 'be-clean') . '|scroll', 
				esc_html__('Fixed', 'be-clean') . '|fixed' 
			) 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'be-clean' . '_error_bg_size', 
			'title' => esc_html__('Background Size', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'cover', 
			'choices' => array( 
				esc_html__('Auto', 'be-clean') . '|auto', 
				esc_html__('Cover', 'be-clean') . '|cover', 
				esc_html__('Contain', 'be-clean') . '|contain' 
			) 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'be-clean' . '_error_search', 
			'title' => esc_html__('Search Line', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'be-clean' . '_error_sitemap_button', 
			'title' => esc_html__('Sitemap Button', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'be-clean' . '_error_sitemap_link', 
			'title' => esc_html__('Sitemap Page URL', 'be-clean'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => '', 
			'class' => '' 
		);
		
		break;
	case 'code':
		$options[] = array( 
			'section' => 'code_section', 
			'id' => 'be-clean' . '_custom_css', 
			'title' => esc_html__('Custom CSS', 'be-clean'), 
			'desc' => '', 
			'type' => 'textarea', 
			'std' => '', 
			'class' => 'allowlinebreaks' 
		);
		
		$options[] = array( 
			'section' => 'code_section', 
			'id' => 'be-clean' . '_custom_js', 
			'title' => esc_html__('Custom JavaScript', 'be-clean'), 
			'desc' => '', 
			'type' => 'textarea', 
			'std' => '', 
			'class' => 'allowlinebreaks' 
		);
		
		$options[] = array( 
			'section' => 'code_section', 
			'id' => 'be-clean' . '_gmap_api_key', 
			'title' => esc_html__('Google Maps API key', 'be-clean'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => '', 
			'class' => '' 
		);
		
		$options[] = array( 
			'section' => 'code_section', 
			'id' => 'be-clean' . '_api_key', 
			'title' => esc_html__('Twitter API key', 'be-clean'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => '', 
			'class' => '' 
		);
		
		$options[] = array( 
			'section' => 'code_section', 
			'id' => 'be-clean' . '_api_secret', 
			'title' => esc_html__('Twitter API secret', 'be-clean'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => '', 
			'class' => '' 
		);
		
		$options[] = array( 
			'section' => 'code_section', 
			'id' => 'be-clean' . '_access_token', 
			'title' => esc_html__('Twitter Access token', 'be-clean'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => '', 
			'class' => '' 
		);
		
		$options[] = array( 
			'section' => 'code_section', 
			'id' => 'be-clean' . '_access_token_secret', 
			'title' => esc_html__('Twitter Access token secret', 'be-clean'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => '', 
			'class' => '' 
		);
		
		break;
	case 'recaptcha':
		$options[] = array( 
			'section' => 'recaptcha_section', 
			'id' => 'be-clean' . '_recaptcha_public_key', 
			'title' => esc_html__('reCAPTCHA Public Key', 'be-clean'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => '', 
			'class' => '' 
		);
		
		$options[] = array( 
			'section' => 'recaptcha_section', 
			'id' => 'be-clean' . '_recaptcha_private_key', 
			'title' => esc_html__('reCAPTCHA Private Key', 'be-clean'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => '', 
			'class' => '' 
		);
		
		break;
	}
	
	return $options;	
}

