<?php 
/**
 * @package 	WordPress
 * @subpackage 	Be Clean
 * @version		1.0.3
 * 
 * Admin Panel Post, Project, Profile & Donations Campaign Settings
 * Created by CMSMasters
 * 
 */


function be_clean_options_single_tabs() {
	$tabs = array();
	
	
	$tabs['post'] = esc_attr__('Post', 'be-clean');
	
	if (CMSMASTERS_PROJECT_COMPATIBLE && class_exists('Cmsmasters_Projects')) {
		$tabs['project'] = esc_attr__('Project', 'be-clean');
	}
	
	if (CMSMASTERS_PROFILE_COMPATIBLE && class_exists('Cmsmasters_Profiles')) {
		$tabs['profile'] = esc_attr__('Profile', 'be-clean');
	}
	
	if (CMSMASTERS_DONATIONS) {
		$tabs['campaign'] = esc_attr__('Campaign', 'be-clean');
	}
	
	
	return $tabs;
}


function be_clean_options_single_sections() {
	$tab = be_clean_get_the_tab();
	
	
	switch ($tab) {
	case 'post':
		$sections = array();
		
		$sections['post_section'] = esc_attr__('Blog Post Options', 'be-clean');
		
		
		break;
	case 'project':
		$sections = array();
		
		$sections['project_section'] = esc_attr__('Portfolio Project Options', 'be-clean');
		
		
		break;
	case 'profile':
		$sections = array();
		
		$sections['profile_section'] = esc_attr__('Person Block Profile Options', 'be-clean');
		
		
		break;
	case 'campaign':
		$sections = array();
		
		$sections['campaign_section'] = esc_attr__('Donations Campaign Options', 'be-clean');
		
		
		break;
	default:
		$sections = array();
		
		
		break;
	}
	
	
	return $sections;
} 


function be_clean_options_single_fields($set_tab = false) {
	if ($set_tab) {
		$tab = $set_tab;
	} else {
		$tab = be_clean_get_the_tab();
	}
	
	
	$options = array();
	
	
	switch ($tab) {
	case 'post':
		$options[] = array( 
			'section' => 'post_section', 
			'id' => 'be-clean' . '_blog_post_layout', 
			'title' => esc_html__('Layout Type', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio_img', 
			'std' => 'r_sidebar', 
			'choices' => array( 
				esc_html__('Right Sidebar', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/sidebar_r.jpg' . '|r_sidebar', 
				esc_html__('Left Sidebar', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/sidebar_l.jpg' . '|l_sidebar', 
				esc_html__('Full Width', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/fullwidth.jpg' . '|fullwidth' 
			) 
		);
		
		$options[] = array( 
			'section' => 'post_section', 
			'id' => 'be-clean' . '_blog_post_title', 
			'title' => esc_html__('Post Title', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'post_section', 
			'id' => 'be-clean' . '_blog_post_date', 
			'title' => esc_html__('Post Date', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'post_section', 
			'id' => 'be-clean' . '_blog_post_cat', 
			'title' => esc_html__('Post Categories', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'post_section', 
			'id' => 'be-clean' . '_blog_post_author', 
			'title' => esc_html__('Post Author', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'post_section', 
			'id' => 'be-clean' . '_blog_post_comment', 
			'title' => esc_html__('Post Comments', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'post_section', 
			'id' => 'be-clean' . '_blog_post_tag', 
			'title' => esc_html__('Post Tags', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'post_section', 
			'id' => 'be-clean' . '_blog_post_like', 
			'title' => esc_html__('Post Likes', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'post_section', 
			'id' => 'be-clean' . '_blog_post_nav_box', 
			'title' => esc_html__('Posts Navigation Box', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'post_section', 
			'id' => 'be-clean' . '_blog_post_share_box', 
			'title' => esc_html__('Sharing Box', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'post_section', 
			'id' => 'be-clean' . '_blog_post_author_box', 
			'title' => esc_html__('About Author Box', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'post_section', 
			'id' => 'be-clean' . '_blog_more_posts_box', 
			'title' => esc_html__('More Posts Box', 'be-clean'), 
			'desc' => '', 
			'type' => 'select', 
			'std' => 'popular', 
			'choices' => array( 
				esc_html__('Show Related Posts', 'be-clean') . '|related', 
				esc_html__('Show Popular Posts', 'be-clean') . '|popular', 
				esc_html__('Show Recent Posts', 'be-clean') . '|recent', 
				esc_html__('Hide More Posts Box', 'be-clean') . '|hide' 
			) 
		);
		
		$options[] = array( 
			'section' => 'post_section', 
			'id' => 'be-clean' . '_blog_more_posts_count', 
			'title' => esc_html__('More Posts Box Items Number', 'be-clean'), 
			'desc' => esc_html__('posts', 'be-clean'), 
			'type' => 'number', 
			'std' => '3', 
			'min' => '2', 
			'max' => '20' 
		);
		
		$options[] = array( 
			'section' => 'post_section', 
			'id' => 'be-clean' . '_blog_more_posts_pause', 
			'title' => esc_html__('More Posts Slider Pause Time', 'be-clean'), 
			'desc' => esc_html__("in seconds, if '0' - autoslide disabled", 'be-clean'), 
			'type' => 'number', 
			'std' => '1', 
			'min' => '0', 
			'max' => '20' 
		);
		
		
		break;
	case 'project':
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_project_title', 
			'title' => esc_html__('Project Title', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_project_details_title', 
			'title' => esc_html__('Project Details Title', 'be-clean'), 
			'desc' => esc_html__('Enter a project details block title', 'be-clean'), 
			'type' => 'text', 
			'std' => 'Project details', 
			'class' => '' 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_project_date', 
			'title' => esc_html__('Project Date', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_project_cat', 
			'title' => esc_html__('Project Categories', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_project_author', 
			'title' => esc_html__('Project Author', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_project_comment', 
			'title' => esc_html__('Project Comments', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 0 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_project_tag', 
			'title' => esc_html__('Project Tags', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 0 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_project_like', 
			'title' => esc_html__('Project Likes', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_project_link', 
			'title' => esc_html__('Project Link', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 0 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_project_share_box', 
			'title' => esc_html__('Sharing Box', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_project_nav_box', 
			'title' => esc_html__('Projects Navigation Box', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_project_author_box', 
			'title' => esc_html__('About Author Box', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_more_projects_box', 
			'title' => esc_html__('More Projects Box', 'be-clean'), 
			'desc' => '', 
			'type' => 'select', 
			'std' => 'popular', 
			'choices' => array( 
				esc_html__('Show Related Projects', 'be-clean') . '|related', 
				esc_html__('Show Popular Projects', 'be-clean') . '|popular', 
				esc_html__('Show Recent Projects', 'be-clean') . '|recent', 
				esc_html__('Hide More Projects Box', 'be-clean') . '|hide' 
			) 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_more_projects_count', 
			'title' => esc_html__('More Projects Box Items Number', 'be-clean'), 
			'desc' => esc_html__('projects', 'be-clean'), 
			'type' => 'number', 
			'std' => '4', 
			'min' => '2', 
			'max' => '20' 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_more_projects_pause', 
			'title' => esc_html__('More Projects Slider Pause Time', 'be-clean'), 
			'desc' => esc_html__("in seconds, if '0' - autoslide disabled", 'be-clean'), 
			'type' => 'number', 
			'std' => '1', 
			'min' => '0', 
			'max' => '20' 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_project_slug', 
			'title' => esc_html__('Project Slug', 'be-clean'), 
			'desc' => esc_html__('Enter a page slug that should be used for your projects single item', 'be-clean'), 
			'type' => 'text', 
			'std' => 'project', 
			'class' => '' 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_pj_categs_slug', 
			'title' => esc_html__('Project Categories Slug', 'be-clean'), 
			'desc' => esc_html__('Enter page slug that should be used on projects categories archive page', 'be-clean'), 
			'type' => 'text', 
			'std' => 'pj-categs', 
			'class' => '' 
		);
		
		$options[] = array( 
			'section' => 'project_section', 
			'id' => 'be-clean' . '_portfolio_pj_tags_slug', 
			'title' => esc_html__('Project Tags Slug', 'be-clean'), 
			'desc' => esc_html__('Enter page slug that should be used on projects tags archive page', 'be-clean'), 
			'type' => 'text', 
			'std' => 'pj-tags', 
			'class' => '' 
		);
		
		
		break;
	case 'profile':
		$options[] = array( 
			'section' => 'profile_section', 
			'id' => 'be-clean' . '_profile_post_title', 
			'title' => esc_html__('Profile Title', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'profile_section', 
			'id' => 'be-clean' . '_profile_post_details_title', 
			'title' => esc_html__('Profile Details Title', 'be-clean'), 
			'desc' => esc_html__('Enter a profile details block title', 'be-clean'), 
			'type' => 'text', 
			'std' => 'Profile details', 
			'class' => '' 
		);
		
		$options[] = array( 
			'section' => 'profile_section', 
			'id' => 'be-clean' . '_profile_post_cat', 
			'title' => esc_html__('Profile Categories', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'profile_section', 
			'id' => 'be-clean' . '_profile_post_comment', 
			'title' => esc_html__('Profile Comments', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'profile_section', 
			'id' => 'be-clean' . '_profile_post_like', 
			'title' => esc_html__('Profile Likes', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'profile_section', 
			'id' => 'be-clean' . '_profile_post_nav_box', 
			'title' => esc_html__('Profiles Navigation Box', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'profile_section', 
			'id' => 'be-clean' . '_profile_post_share_box', 
			'title' => esc_html__('Sharing Box', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'profile_section', 
			'id' => 'be-clean' . '_profile_post_slug', 
			'title' => esc_html__('Profile Slug', 'be-clean'), 
			'desc' => esc_html__('Enter a page slug that should be used for your profiles single item', 'be-clean'), 
			'type' => 'text', 
			'std' => 'profile', 
			'class' => '' 
		);
		
		$options[] = array( 
			'section' => 'profile_section', 
			'id' => 'be-clean' . '_profile_pl_categs_slug', 
			'title' => esc_html__('Profile Categories Slug', 'be-clean'), 
			'desc' => esc_html__('Enter page slug that should be used on profiles categories archive page', 'be-clean'), 
			'type' => 'text', 
			'std' => 'pl-categs', 
			'class' => '' 
		);
		
		
		break;
	case 'campaign':
		$options[] = array( 
			'section' => 'campaign_section', 
			'id' => 'be-clean' . '_donations_campaign_layout', 
			'title' => esc_html__('Layout Type', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio_img', 
			'std' => 'r_sidebar', 
			'choices' => array( 
				esc_html__('Right Sidebar', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/sidebar_r.jpg' . '|r_sidebar', 
				esc_html__('Left Sidebar', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/sidebar_l.jpg' . '|l_sidebar', 
				esc_html__('Full Width', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/fullwidth.jpg' . '|fullwidth' 
			) 
		);
		
		$options[] = array( 
			'section' => 'campaign_section', 
			'id' => 'be-clean' . '_donations_campaign_title', 
			'title' => esc_html__('Campaign Title', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'campaign_section', 
			'id' => 'be-clean' . '_donations_campaign_date', 
			'title' => esc_html__('Campaign Date', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'campaign_section', 
			'id' => 'be-clean' . '_donations_campaign_cat', 
			'title' => esc_html__('Campaign Categories', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'campaign_section', 
			'id' => 'be-clean' . '_donations_campaign_author', 
			'title' => esc_html__('Campaign Author', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'campaign_section', 
			'id' => 'be-clean' . '_donations_campaign_comment', 
			'title' => esc_html__('Campaign Comments', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'campaign_section', 
			'id' => 'be-clean' . '_donations_campaign_tag', 
			'title' => esc_html__('Campaign Tags', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'campaign_section', 
			'id' => 'be-clean' . '_donations_campaign_like', 
			'title' => esc_html__('Campaign Likes', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'campaign_section', 
			'id' => 'be-clean' . '_donations_campaign_nav_box', 
			'title' => esc_html__('Campaign Navigation Box', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'campaign_section', 
			'id' => 'be-clean' . '_donations_campaign_share_box', 
			'title' => esc_html__('Sharing Box', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'campaign_section', 
			'id' => 'be-clean' . '_donations_campaign_author_box', 
			'title' => esc_html__('About Author Box', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'campaign_section', 
			'id' => 'be-clean' . '_donations_more_campaigns_box', 
			'title' => esc_html__('More Campaigns Box', 'be-clean'), 
			'desc' => '', 
			'type' => 'select', 
			'std' => 'related', 
			'choices' => array( 
				esc_html__('Show Related Campaigns', 'be-clean') . '|related', 
				esc_html__('Show Popular Campaigns', 'be-clean') . '|popular', 
				esc_html__('Show Recent Campaigns', 'be-clean') . '|recent', 
				esc_html__('Hide More Campaigns Box', 'be-clean') . '|hide' 
			) 
		);
		
		$options[] = array( 
			'section' => 'campaign_section', 
			'id' => 'be-clean' . '_donations_more_campaigns_count', 
			'title' => esc_html__('More Campaigns Box Items Number', 'be-clean'), 
			'desc' => esc_html__('campaigns', 'be-clean'), 
			'type' => 'number', 
			'std' => '3', 
			'min' => '2', 
			'max' => '20' 
		);
		
		$options[] = array( 
			'section' => 'campaign_section', 
			'id' => 'be-clean' . '_donations_more_campaigns_pause', 
			'title' => esc_html__('More Campaigns Slider Pause Time', 'be-clean'), 
			'desc' => esc_html__("in seconds, if '0' - autoslide disabled", 'be-clean'), 
			'type' => 'number', 
			'std' => '0', 
			'min' => '0', 
			'max' => '20' 
		);
		
		$options[] = array( 
			'section' => 'campaign_section', 
			'id' => 'be-clean' . '_donations_campaign_slug', 
			'title' => esc_html__('Campaign Slug', 'be-clean'), 
			'desc' => esc_html__('Enter a page slug that should be used for your donations campaign single item', 'be-clean'), 
			'type' => 'text', 
			'std' => 'campaign', 
			'class' => '' 
		);
		
		
		break;
	}
	
	
	return $options;
}

