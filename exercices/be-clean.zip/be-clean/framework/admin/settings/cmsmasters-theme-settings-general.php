<?php 
/**
 * @package 	WordPress
 * @subpackage 	Be Clean
 * @version 	1.0.3
 * 
 * Admin Panel General Options
 * Created by CMSMasters
 * 
 */


function be_clean_options_general_tabs() {
	$cmsmasters_option = be_clean_get_global_options();
	
	$tabs = array();
	
	$tabs['general'] = esc_attr__('General', 'be-clean');
	
	if ($cmsmasters_option['be-clean' . '_theme_layout'] === 'boxed') {
		$tabs['bg'] = esc_attr__('Background', 'be-clean');
	}
	
	$tabs['header'] = esc_attr__('Header', 'be-clean');
	$tabs['content'] = esc_attr__('Content', 'be-clean');
	$tabs['footer'] = esc_attr__('Footer', 'be-clean');
	
	return $tabs;
}


function be_clean_options_general_sections() {
	$tab = be_clean_get_the_tab();
	
	switch ($tab) {
	case 'general':
		$sections = array();
		
		$sections['general_section'] = esc_attr__('General Options', 'be-clean');
		
		break;
	case 'bg':
		$sections = array();
		
		$sections['bg_section'] = esc_attr__('Background Options', 'be-clean');
		
		break;
	case 'header':
		$sections = array();
		
		$sections['header_section'] = esc_attr__('Header Options', 'be-clean');
		
		break;
	case 'content':
		$sections = array();
		
		$sections['content_section'] = esc_attr__('Content Options', 'be-clean');
		
		break;
	case 'footer':
		$sections = array();
		
		$sections['footer_section'] = esc_attr__('Footer Options', 'be-clean');
		
		break;
	default:
		$sections = array();
		
		
		break;
	}
	
	return $sections;
} 


function be_clean_options_general_fields($set_tab = false) {
	if ($set_tab) {
		$tab = $set_tab;
	} else {
		$tab = be_clean_get_the_tab();
	}
	
	$options = array();
	
	switch ($tab) {
	case 'general':
		$options[] = array( 
			'section' => 'general_section', 
			'id' => 'be-clean' . '_theme_layout', 
			'title' => esc_html__('Theme Layout', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'liquid', 
			'choices' => array( 
				esc_html__('Liquid', 'be-clean') . '|liquid', 
				esc_html__('Boxed', 'be-clean') . '|boxed' 
			) 
		);
		
		$options[] = array( 
			'section' => 'general_section', 
			'id' => 'be-clean' . '_logo_type', 
			'title' => esc_html__('Logo Type', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'image', 
			'choices' => array( 
				esc_html__('Image', 'be-clean') . '|image', 
				esc_html__('Text', 'be-clean') . '|text' 
			) 
		);
		
		$options[] = array( 
			'section' => 'general_section', 
			'id' => 'be-clean' . '_logo_url', 
			'title' => esc_html__('Logo Image', 'be-clean'), 
			'desc' => esc_html__('Choose your website logo image.', 'be-clean'), 
			'type' => 'upload', 
			'std' => '|' . get_template_directory_uri() . '/img/logo.png', 
			'frame' => 'select', 
			'multiple' => false 
		);
		
		$options[] = array( 
			'section' => 'general_section', 
			'id' => 'be-clean' . '_logo_url_retina', 
			'title' => esc_html__('Retina Logo Image', 'be-clean'), 
			'desc' => esc_html__('Choose logo image for retina displays.', 'be-clean'), 
			'type' => 'upload', 
			'std' => '|' . get_template_directory_uri() . '/img/logo_retina.png', 
			'frame' => 'select', 
			'multiple' => false 
		);
		
		$options[] = array( 
			'section' => 'general_section', 
			'id' => 'be-clean' . '_logo_title', 
			'title' => esc_html__('Logo Title', 'be-clean'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => ((get_bloginfo('name')) ? get_bloginfo('name') : 'Be Clean'), 
			'class' => 'nohtml' 
		);
		
		$options[] = array( 
			'section' => 'general_section', 
			'id' => 'be-clean' . '_logo_subtitle', 
			'title' => esc_html__('Logo Subtitle', 'be-clean'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => '', 
			'class' => 'nohtml' 
		);
		
		$options[] = array( 
			'section' => 'general_section', 
			'id' => 'be-clean' . '_logo_custom_color', 
			'title' => esc_html__('Custom Text Colors', 'be-clean'), 
			'desc' => esc_html__('enable', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 0 
		);
		
		$options[] = array( 
			'section' => 'general_section', 
			'id' => 'be-clean' . '_logo_title_color', 
			'title' => esc_html__('Logo Title Color', 'be-clean'), 
			'desc' => '', 
			'type' => 'rgba', 
			'std' => '' 
		);
		
		$options[] = array( 
			'section' => 'general_section', 
			'id' => 'be-clean' . '_logo_subtitle_color', 
			'title' => esc_html__('Logo Subtitle Color', 'be-clean'), 
			'desc' => '', 
			'type' => 'rgba', 
			'std' => '' 
		);
		
		break;
	case 'bg':
		$options[] = array( 
			'section' => 'bg_section', 
			'id' => 'be-clean' . '_bg_col', 
			'title' => esc_html__('Background Color', 'be-clean'), 
			'desc' => '', 
			'type' => 'color', 
			'std' => '#ffffff' 
		);
		
		$options[] = array( 
			'section' => 'bg_section', 
			'id' => 'be-clean' . '_bg_img_enable', 
			'title' => esc_html__('Background Image Visibility', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 0 
		);
		
		$options[] = array( 
			'section' => 'bg_section', 
			'id' => 'be-clean' . '_bg_img', 
			'title' => esc_html__('Background Image', 'be-clean'), 
			'desc' => esc_html__('Choose your custom website background image url.', 'be-clean'), 
			'type' => 'upload', 
			'std' => '', 
			'frame' => 'select', 
			'multiple' => false 
		);
		
		$options[] = array( 
			'section' => 'bg_section', 
			'id' => 'be-clean' . '_bg_rep', 
			'title' => esc_html__('Background Repeat', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'no-repeat', 
			'choices' => array( 
				esc_html__('No Repeat', 'be-clean') . '|no-repeat', 
				esc_html__('Repeat Horizontally', 'be-clean') . '|repeat-x', 
				esc_html__('Repeat Vertically', 'be-clean') . '|repeat-y', 
				esc_html__('Repeat', 'be-clean') . '|repeat' 
			) 
		);
		
		$options[] = array( 
			'section' => 'bg_section', 
			'id' => 'be-clean' . '_bg_pos', 
			'title' => esc_html__('Background Position', 'be-clean'), 
			'desc' => '', 
			'type' => 'select', 
			'std' => 'top center', 
			'choices' => array( 
				esc_html__('Top Left', 'be-clean') . '|top left', 
				esc_html__('Top Center', 'be-clean') . '|top center', 
				esc_html__('Top Right', 'be-clean') . '|top right', 
				esc_html__('Center Left', 'be-clean') . '|center left', 
				esc_html__('Center Center', 'be-clean') . '|center center', 
				esc_html__('Center Right', 'be-clean') . '|center right', 
				esc_html__('Bottom Left', 'be-clean') . '|bottom left', 
				esc_html__('Bottom Center', 'be-clean') . '|bottom center', 
				esc_html__('Bottom Right', 'be-clean') . '|bottom right' 
			) 
		);
		
		$options[] = array( 
			'section' => 'bg_section', 
			'id' => 'be-clean' . '_bg_att', 
			'title' => esc_html__('Background Attachment', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'scroll', 
			'choices' => array( 
				esc_html__('Scroll', 'be-clean') . '|scroll', 
				esc_html__('Fixed', 'be-clean') . '|fixed' 
			) 
		);
		
		$options[] = array( 
			'section' => 'bg_section', 
			'id' => 'be-clean' . '_bg_size', 
			'title' => esc_html__('Background Size', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'cover', 
			'choices' => array( 
				esc_html__('Auto', 'be-clean') . '|auto', 
				esc_html__('Cover', 'be-clean') . '|cover', 
				esc_html__('Contain', 'be-clean') . '|contain' 
			) 
		);
		
		break;
	case 'header':
		$options[] = array( 
			'section' => 'header_section', 
			'id' => 'be-clean' . '_fixed_header', 
			'title' => esc_html__('Fixed Header', 'be-clean'), 
			'desc' => esc_html__('enable', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'header_section', 
			'id' => 'be-clean' . '_header_overlaps', 
			'title' => esc_html__('Header Overlaps Content', 'be-clean'), 
			'desc' => esc_html__('enable', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 0 
		);
		
		$options[] = array( 
			'section' => 'header_section', 
			'id' => 'be-clean' . '_header_top_line', 
			'title' => esc_html__('Top Line', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'header_section', 
			'id' => 'be-clean' . '_header_top_height', 
			'title' => esc_html__('Top Height', 'be-clean'), 
			'desc' => esc_html__('pixels', 'be-clean'), 
			'type' => 'number', 
			'std' => '32', 
			'min' => '30' 
		);
		
		$options[] = array( 
			'section' => 'header_section', 
			'id' => 'be-clean' . '_header_top_line_short_info', 
			'title' => esc_html__('Top Short Info', 'be-clean'), 
			'desc' => '<strong>' . esc_html__('HTML tags are allowed!', 'be-clean') . '</strong>', 
			'type' => 'textarea', 
			'std' => '', 
			'class' => '' 
		);
		
	if (CMSMASTERS_DONATIONS) {
		$options[] = array( 
			'section' => 'header_section', 
			'id' => 'be-clean' . '_header_top_line_donations_but', 
			'title' => esc_html__('Top Donations Button', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 0 
		);
		
		$options[] = array( 
			'section' => 'header_section', 
			'id' => 'be-clean' . '_header_top_line_donations_but_text', 
			'title' => esc_html__('Top Donations Button Text', 'be-clean'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => esc_html__('Donate Now!', 'be-clean'), 
			'class' => 'nohtml' 
		);
	}
		
		$options[] = array( 
			'section' => 'header_section', 
			'id' => 'be-clean' . '_header_top_line_add_cont', 
			'title' => esc_html__('Top Additional Content', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'social', 
			'choices' => array( 
				esc_html__('None', 'be-clean') . '|none', 
				esc_html__('Top Line Social Icons', 'be-clean') . '|social', 
				esc_html__('Top Line Navigation', 'be-clean') . '|nav' 
			) 
		);
		
		$options[] = array( 
			'section' => 'header_section', 
			'id' => 'be-clean' . '_header_styles', 
			'title' => esc_html__('Header Styles', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'default', 
			'choices' => array( 
				esc_html__('Default Style', 'be-clean') . '|default', 
				esc_html__('Compact Style Left Navigation', 'be-clean') . '|l_nav', 
				esc_html__('Compact Style Right Navigation', 'be-clean') . '|r_nav', 
				esc_html__('Compact Style Center Navigation', 'be-clean') . '|c_nav'
			) 
		);
		
		$options[] = array( 
			'section' => 'header_section', 
			'id' => 'be-clean' . '_header_mid_height', 
			'title' => esc_html__('Header Middle Height', 'be-clean'), 
			'desc' => esc_html__('pixels', 'be-clean'), 
			'type' => 'number', 
			'std' => '108', 
			'min' => '80' 
		);
		
		$options[] = array( 
			'section' => 'header_section', 
			'id' => 'be-clean' . '_header_bot_height', 
			'title' => esc_html__('Header Bottom Height', 'be-clean'), 
			'desc' => esc_html__('pixels', 'be-clean'), 
			'type' => 'number', 
			'std' => '50', 
			'min' => '40' 
		);
		
		$options[] = array( 
			'section' => 'header_section', 
			'id' => 'be-clean' . '_header_search', 
			'title' => esc_html__('Header Search', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 0 
		);
		
	if (CMSMASTERS_DONATIONS) {
		$options[] = array( 
			'section' => 'header_section', 
			'id' => 'be-clean' . '_header_donations_but', 
			'title' => esc_html__('Header Donations Button', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'header_section', 
			'id' => 'be-clean' . '_header_donations_but_text', 
			'title' => esc_html__('Header Donations Button Text', 'be-clean'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => esc_html__('Donate Now!', 'be-clean'), 
			'class' => 'nohtml' 
		);
	}
		
		$options[] = array( 
			'section' => 'header_section', 
			'id' => 'be-clean' . '_header_add_cont', 
			'title' => esc_html__('Header Additional Content', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'social', 
			'choices' => array( 
				esc_html__('None', 'be-clean') . '|none', 
				esc_html__('Header Social Icons', 'be-clean') . '|social', 
				esc_html__('Header Custom HTML', 'be-clean') . '|cust_html' 
			) 
		);
		
		$options[] = array( 
			'section' => 'header_section', 
			'id' => 'be-clean' . '_header_add_cont_cust_html', 
			'title' => esc_html__('Header Custom HTML', 'be-clean'), 
			'desc' => '<strong>' . esc_html__('HTML tags are allowed!', 'be-clean') . '</strong>', 
			'type' => 'textarea', 
			'std' => '', 
			'class' => '' 
		);
		
		break;
	case 'content':
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_layout', 
			'title' => esc_html__('Layout Type by Default', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio_img', 
			'std' => 'r_sidebar', 
			'choices' => array( 
				esc_html__('Right Sidebar', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/sidebar_r.jpg' . '|r_sidebar', 
				esc_html__('Left Sidebar', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/sidebar_l.jpg' . '|l_sidebar', 
				esc_html__('Full Width', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/fullwidth.jpg' . '|fullwidth' 
			) 
		);
		
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_archives_layout', 
			'title' => esc_html__('Archives Layout Type', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio_img', 
			'std' => 'r_sidebar', 
			'choices' => array( 
				esc_html__('Right Sidebar', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/sidebar_r.jpg' . '|r_sidebar', 
				esc_html__('Left Sidebar', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/sidebar_l.jpg' . '|l_sidebar', 
				esc_html__('Full Width', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/fullwidth.jpg' . '|fullwidth' 
			) 
		);
		
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_search_layout', 
			'title' => esc_html__('Search Layout Type', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio_img', 
			'std' => 'r_sidebar', 
			'choices' => array( 
				esc_html__('Right Sidebar', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/sidebar_r.jpg' . '|r_sidebar', 
				esc_html__('Left Sidebar', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/sidebar_l.jpg' . '|l_sidebar', 
				esc_html__('Full Width', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/fullwidth.jpg' . '|fullwidth' 
			) 
		);
		
	if (CMSMASTERS_EVENTS_CALENDAR) {
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_events_layout', 
			'title' => esc_html__('Events Calendar Layout Type', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio_img', 
			'std' => 'fullwidth', 
			'choices' => array( 
				esc_html__('Right Sidebar', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/sidebar_r.jpg' . '|r_sidebar', 
				esc_html__('Left Sidebar', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/sidebar_l.jpg' . '|l_sidebar', 
				esc_html__('Full Width', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/fullwidth.jpg' . '|fullwidth' 
			) 
		);
	}
		
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_other_layout', 
			'title' => esc_html__('Other Layout Type', 'be-clean'), 
			'desc' => 'Layout for pages of non-listed types', 
			'type' => 'radio_img', 
			'std' => 'r_sidebar', 
			'choices' => array( 
				esc_html__('Right Sidebar', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/sidebar_r.jpg' . '|r_sidebar', 
				esc_html__('Left Sidebar', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/sidebar_l.jpg' . '|l_sidebar', 
				esc_html__('Full Width', 'be-clean') . '|' . get_template_directory_uri() . '/framework/admin/inc/img/fullwidth.jpg' . '|fullwidth' 
			) 
		);
		
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_heading_alignment', 
			'title' => esc_html__('Heading Alignment by Default', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'left', 
			'choices' => array( 
				esc_html__('Left', 'be-clean') . '|left', 
				esc_html__('Right', 'be-clean') . '|right', 
				esc_html__('Center', 'be-clean') . '|center' 
			) 
		);
		
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_heading_scheme', 
			'title' => esc_html__('Heading Custom Color Scheme by Default', 'be-clean'), 
			'desc' => '', 
			'type' => 'select_scheme', 
			'std' => 'default', 
			'choices' => cmsmasters_color_schemes_list() 
		);
		
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_heading_bg_image_enable', 
			'title' => esc_html__('Heading Background Image Visibility by Default', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 0 
		);
		
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_heading_bg_image', 
			'title' => esc_html__('Heading Background Image by Default', 'be-clean'), 
			'desc' => esc_html__('Choose your custom heading background image by default.', 'be-clean'), 
			'type' => 'upload', 
			'std' => '', 
			'frame' => 'select', 
			'multiple' => false 
		);
		
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_heading_bg_repeat', 
			'title' => esc_html__('Heading Background Repeat by Default', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'no-repeat', 
			'choices' => array( 
				esc_html__('No Repeat', 'be-clean') . '|no-repeat', 
				esc_html__('Repeat Horizontally', 'be-clean') . '|repeat-x', 
				esc_html__('Repeat Vertically', 'be-clean') . '|repeat-y', 
				esc_html__('Repeat', 'be-clean') . '|repeat' 
			) 
		);
		
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_heading_bg_attachment', 
			'title' => esc_html__('Heading Background Attachment by Default', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'scroll', 
			'choices' => array( 
				esc_html__('Scroll', 'be-clean') . '|scroll', 
				esc_html__('Fixed', 'be-clean') . '|fixed' 
			) 
		);
		
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_heading_bg_size', 
			'title' => esc_html__('Heading Background Size by Default', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'cover', 
			'choices' => array( 
				esc_html__('Auto', 'be-clean') . '|auto', 
				esc_html__('Cover', 'be-clean') . '|cover', 
				esc_html__('Contain', 'be-clean') . '|contain' 
			) 
		);
		
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_heading_bg_color', 
			'title' => esc_html__('Heading Background Color Overlay by Default', 'be-clean'), 
			'desc' => '',  
			'type' => 'rgba', 
			'std' => '' 
		);
		
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_heading_height', 
			'title' => esc_html__('Heading Height by Default', 'be-clean'), 
			'desc' => esc_html__('pixels', 'be-clean'), 
			'type' => 'number', 
			'std' => '80', 
			'min' => '0' 
		);
		
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_breadcrumbs', 
			'title' => esc_html__('Breadcrumbs Visibility by Default', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_bottom_scheme', 
			'title' => esc_html__('Bottom Custom Color Scheme', 'be-clean'), 
			'desc' => '', 
			'type' => 'select_scheme', 
			'std' => 'first', 
			'choices' => cmsmasters_color_schemes_list() 
		);
		
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_bottom_sidebar', 
			'title' => esc_html__('Bottom Sidebar Visibility by Default', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'content_section', 
			'id' => 'be-clean' . '_bottom_sidebar_layout', 
			'title' => esc_html__('Bottom Sidebar Layout by Default', 'be-clean'), 
			'desc' => '', 
			'type' => 'select', 
			'std' => '14141414', 
			'choices' => array( 
				'1/1|11', 
				'1/2 + 1/2|1212', 
				'1/3 + 2/3|1323', 
				'2/3 + 1/3|2313', 
				'1/4 + 3/4|1434', 
				'3/4 + 1/4|3414', 
				'1/3 + 1/3 + 1/3|131313', 
				'1/2 + 1/4 + 1/4|121414', 
				'1/4 + 1/2 + 1/4|141214', 
				'1/4 + 1/4 + 1/2|141412', 
				'1/4 + 1/4 + 1/4 + 1/4|14141414' 
			) 
		);
		
		break;
	case 'footer':
		$options[] = array( 
			'section' => 'footer_section', 
			'id' => 'be-clean' . '_footer_scheme', 
			'title' => esc_html__('Footer Custom Color Scheme', 'be-clean'), 
			'desc' => '', 
			'type' => 'select_scheme', 
			'std' => 'footer', 
			'choices' => cmsmasters_color_schemes_list() 
		);
		
		$options[] = array( 
			'section' => 'footer_section', 
			'id' => 'be-clean' . '_footer_type', 
			'title' => esc_html__('Footer Type', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'small', 
			'choices' => array( 
				esc_html__('Default', 'be-clean') . '|default', 
				esc_html__('Small', 'be-clean') . '|small' 
			) 
		);
		
		$options[] = array( 
			'section' => 'footer_section', 
			'id' => 'be-clean' . '_footer_additional_content', 
			'title' => esc_html__('Footer Additional Content', 'be-clean'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => 'nav', 
			'choices' => array( 
				esc_html__('None', 'be-clean') . '|none', 
				esc_html__('Footer Navigation', 'be-clean') . '|nav', 
				esc_html__('Social Icons', 'be-clean') . '|social', 
				esc_html__('Custom HTML', 'be-clean') . '|text' 
			) 
		);
		
		$options[] = array( 
			'section' => 'footer_section', 
			'id' => 'be-clean' . '_footer_logo', 
			'title' => esc_html__('Footer Logo', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'footer_section', 
			'id' => 'be-clean' . '_footer_logo_url', 
			'title' => esc_html__('Footer Logo', 'be-clean'), 
			'desc' => esc_html__('Choose your website footer logo image.', 'be-clean'), 
			'type' => 'upload', 
			'std' => '|' . get_template_directory_uri() . '/img/logo_footer.png', 
			'frame' => 'select', 
			'multiple' => false 
		);
		
		$options[] = array( 
			'section' => 'footer_section', 
			'id' => 'be-clean' . '_footer_logo_url_retina', 
			'title' => esc_html__('Footer Logo for Retina', 'be-clean'), 
			'desc' => esc_html__('Choose your website footer logo image for retina.', 'be-clean'), 
			'type' => 'upload', 
			'std' => '|' . get_template_directory_uri() . '/img/logo_footer_retina.png', 
			'frame' => 'select', 
			'multiple' => false 
		);
		
		$options[] = array( 
			'section' => 'footer_section', 
			'id' => 'be-clean' . '_footer_nav', 
			'title' => esc_html__('Footer Navigation', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'footer_section', 
			'id' => 'be-clean' . '_footer_social', 
			'title' => esc_html__('Footer Social Icons', 'be-clean'), 
			'desc' => esc_html__('show', 'be-clean'), 
			'type' => 'checkbox', 
			'std' => 1 
		);
		
		$options[] = array( 
			'section' => 'footer_section', 
			'id' => 'be-clean' . '_footer_html', 
			'title' => esc_html__('Footer Custom HTML', 'be-clean'), 
			'desc' => '<strong>' . esc_html__('HTML tags are allowed!', 'be-clean') . '</strong>', 
			'type' => 'textarea', 
			'std' => '', 
			'class' => '' 
		);
		
		$options[] = array( 
			'section' => 'footer_section', 
			'id' => 'be-clean' . '_footer_copyright', 
			'title' => esc_html__('Copyright Text', 'be-clean'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => 'Be Clean' . ' &copy; 2016 / ' . esc_html__('All Rights Reserved', 'be-clean'), 
			'class' => '' 
		);
		
		break;
	}
	
	return $options;	
}

