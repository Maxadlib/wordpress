<?php
/**
 * @package 	WordPress
 * @subpackage 	Be Clean
 * @version		1.0.3
 * 
 * Website Footer Template
 * Created by CMSMasters
 * 
 */


$cmsmasters_option = be_clean_get_global_options();
?>


		</div>
	</div>
</div>
<!-- _________________________ Finish Middle _________________________ -->
<?php 

get_sidebar('bottom');

?>
<a href="javascript:void(0);" id="slide_top" class="cmsmasters_theme_icon_slide_top"></a>
</div>
<!-- _________________________ Finish Main _________________________ -->

<!-- _________________________ Start Footer _________________________ -->
<footer id="footer" role="contentinfo" class="<?php echo 'cmsmasters_color_scheme_' . $cmsmasters_option['be-clean' . '_footer_scheme'] . ($cmsmasters_option['be-clean' . '_footer_type'] == 'default' ? ' cmsmasters_footer_default' : ' cmsmasters_footer_small'); ?>">
	<div class="footer_inner">
	<?php 
		be_clean_footer_logo($cmsmasters_option);
		
		
		be_clean_get_footer_custom_html($cmsmasters_option);
		
		
		be_clean_get_footer_nav($cmsmasters_option);
		
		
		be_clean_get_footer_social_icons($cmsmasters_option);
	?>
		<span class="footer_copyright copyright"><?php echo esc_html(stripslashes($cmsmasters_option['be-clean' . '_footer_copyright'])); ?></span>
	</div>
</footer>
<!-- _________________________ Finish Footer _________________________ -->

</div>
<!-- _________________________ Finish Page _________________________ -->

<?php wp_footer(); ?>
</body>
</html>
