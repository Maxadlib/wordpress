<?php
/**
 * @package 	WordPress
 * @subpackage 	Be Clean
 * @version 	1.0.0
 * 
 * Content Composer Client Shortcode
 * Created by CMSMasters
 * 
 */


extract(shortcode_atts($new_atts, $atts));


$counter = 0;

if ($content == null) {
	$content = esc_html__('Name', 'be-clean');
}


if ($logo != '') {
	$client_logo = wp_get_attachment_image_src($logo, 'full');
	
	if ($link != '') {
		$this->clients_atts['client_out'] .= '<div class="cmsmasters_clients_item item' . 
		(($classes != '') ? ' ' . $classes : '') . 
		'">' . "\n" . 
			'<a href="' . (($link != '') ? '' . $link : '') . '" target="_blank">' .  
				'<img src="' . $client_logo[0] . '" alt="' . $content . '" title="' . $content . '" />' . 
			'</a>' . "\n" . 
		'</div>' . "\n";
	} else {
		$this->clients_atts['client_out'] .= '<div class="cmsmasters_clients_item item' . 
		(($classes != '') ? ' ' . $classes : '') . 
		'">' . "\n" . 
			'<img src="' . $client_logo[0] . '" alt="' . $content . '" title="' . $content . '" />' . "\n" .
		'</div>' . "\n";
	}
}


$out = $client_out;

echo $out;

